import numpy as np
import os
import glob
import types
import matplotlib.pyplot as plt
import PyQt5.QtGui
import pyqtgraph as pg
from astropy.table import Table
from collections import defaultdict
from PyQt5.QtCore import QRectF

from ...utils.utils_plots.plot_utils_general import make_palette, adjust_luminosity, adjust_contrast, plot_scale_bar, plot_image_mpl
from ...utils.utils_astro.utils_general import relative_to_world
from ...utils.utils_astro.cat_manip import match_cat2
from ...utils.utils_general.utils_general import find_close_coord
from ...utils.utils_plots.plt_framework import plt_framework




def make_which_colors(self, filled_markers=False, saturation=None) :
    which = self.broad_families if self.which=='all' else self.which
    
    if filled_markers:
        colors = make_palette(len(which), 1, alpha=0.5, sat_fixed=saturation)
    else:
        colors = make_palette(len(which), 1, alpha=0, sat_fixed=saturation)
    
    which_colors_dict = {}
    for i, name in enumerate(which) :
        which_colors_dict[name] = colors[i]
    #for i, mask in enumerate(to_plot_mask):
    #    for multiple_image in cat[mask]:
    #        which_colors_dict[multiple_image['id']] = colors[i]
    return which_colors_dict


def make_full_color_function(families) :
    n_families = len(families)
    def make_full_color_dict(filled_markers=False, saturation=None) :
        if filled_markers:
            colors = make_palette(n_families, 1, alpha=0.5, sat_fixed=saturation)
        else:
            colors = make_palette(n_families, 1, alpha=0, sat_fixed=saturation)
        full_colors_dict = {}
        for i, family in enumerate(families) :
            full_colors_dict[family] = colors[i]
        return full_colors_dict
    return make_full_color_dict


def get_lenstool_file_path(model_dir, name) :
    path_list = glob.glob( os.path.join(model_dir, f"*{name}*.lenstool") )
    if len(path_list)==0 :
        return None
    else :
        if len(path_list)==1 :
            print(f"{name} file found: '" + path_list[0] + "'")
        elif len(path_list)>1 :
            print(f"Several {name} files found: ")
            print(path_list)
            print("Using first item in list: '" + path_list[0] + "'")
        return path_list[0]


def import_multiple_images(self, mult_file_path_or_cat, fits_image, units=None, AttrName='mult', filled_markers=False, saturation=0.8) :
    if type(mult_file_path_or_cat)==str :
        multiple_images = Table(names=['id','family','broad_family','ra','dec','a','b','theta','z','mag','confidence'], dtype=['str','str','str',*['float',]*8])
        with open(mult_file_path_or_cat, 'r') as mult_file:
            for line in mult_file:
                cleaned_line = line.strip()
                if not cleaned_line.startswith("#") and len(cleaned_line)>0 :
                    split_line = cleaned_line.split()
                    row = [split_line[0], '---', '---'] #split_line[0][:-1]
                    for element in split_line[1:8] :
                        row.append(float(element))
                    row.append(0)
                    multiple_images.add_row(row)
        multiple_images['theta'] = multiple_images['theta'] - fits_image.orientation
    else :
        multiple_images = mult_file_path_or_cat.copy()
        
    multiple_images['family'], multiple_images['broad_family'], local_families, local_broad_families, multiple_images['confidence'] = find_families(multiple_images['id'])
    setattr(self, AttrName, fits_image.make_catalog(multiple_images, units=units))
    
    if AttrName=='mult' :
        self.families, indices = np.unique(self.families + local_families, return_index=True)
        self.families = self.families[np.argsort(indices)].tolist()
        
        self.broad_families, indices = np.unique(self.broad_families + local_broad_families, return_index=True)
        self.broad_families = self.broad_families[np.argsort(indices)].tolist()
        
        self.which = self.broad_families.copy()
        self.mult_colors = make_full_color_function(self.broad_families) #make_full_color_function(self.broad_families)
        
    getattr(self, AttrName).saturation = saturation
    
    def make_to_plot_masks() :
        to_plot_masks = {}
        #for i, name in enumerate(self.which) :
        #    other_names_mask = np.full(len(self.which), True)
        #    other_names_mask[i] = False
        #    other_names = np.array(self.which)[other_names_mask]
        #    ambiguous_names = []
        #    for other_name in other_names :
        #        if other_name.startswith(name) :
        #           ambiguous_names.append(other_name)
        #    to_plot_mask = np.full(len(getattr(self, AttrName).cat), False)
        #    for j, im_id in enumerate(getattr(self, AttrName).cat['id']) :
        #        if im_id.startswith(name) and True not in [ im_id.startswith(ambiguous_name) for ambiguous_name in ambiguous_names ] :
        #            to_plot_mask[j] = True
        #    to_plot_masks[name] = to_plot_mask
        for family in self.which :
            to_plot_masks[family] = getattr(self, AttrName).cat['broad_family'] == family
            if len(np.unique(to_plot_masks[family]))==1 and np.unique(to_plot_masks[family])[0]==False :
                to_plot_masks[family] = getattr(self, AttrName).cat['family'] == family
                if len(np.unique(to_plot_masks[family]))==1 and np.unique(to_plot_masks[family])[0]==False :
                    to_plot_masks[family] = getattr(self, AttrName).cat['id'] == family
        return to_plot_masks
    def make_overall_mask() :
        overall_mask = np.full(len(getattr(self, AttrName).cat), False)
        for mask in make_to_plot_masks().values() :
            overall_mask = np.logical_or(overall_mask, mask)
        return overall_mask
    getattr(self, AttrName).masks = make_to_plot_masks
    getattr(self, AttrName).mask = make_overall_mask
    
    lenstool_model = self
    
    def plot_multiple_images(self, scale=1, marker=None, filled_markers=filled_markers, color=None, mpl=False, fontsize=9,
                             make_thumbnails=False, square_size=150, margin=50, distance=200, savefig=False, square_thumbnails=True,
                             boost=[2,1.5,1], linewidth=1.7, text_color='white', text_alpha=0.5, saturation=saturation) :
        self.clear()
        self.saturation = saturation
        
        if color is not None :
            colors_dict = {}
            if type(color[0])==list :
                for i, family in enumerate(lenstool_model.which) :
                    colors_dict[family] = color[i]
            else :
                for i, family in enumerate(lenstool_model.which) :
                    colors_dict[family] = color
        else :
            colors_dict = lenstool_model.mult_colors(filled_markers=filled_markers, saturation=saturation)
        
        cat_contains_ellipse_params = len(np.unique(self.cat['a']))!=1
        count = 0
        for name, mask in self.masks().items() :
            broad_family = name#self.cat['broad_family'][ np.where(self.cat['family']==name)[0][0] ]
            for multiple_image in self.cat[mask] :
                # Remove the *1000
                if not cat_contains_ellipse_params :
                    a, b = scale*40, scale*40
                else :
                    a, b = multiple_image['a']*scale, multiple_image['b']*scale
                color = colors_dict[broad_family].copy()
                if multiple_image['confidence']==1 :
                    color/=2
                elif multiple_image['confidence']==0 :
                    color/=4
                ellipse = self.plot_one_object(multiple_image['x'], multiple_image['y'], a, b, 
                                               multiple_image['theta'], count, color=color, 
                                               linewidth=linewidth, marker=marker, size=scale*15)
                #self.qtItems[count] = ellipse
                self.qtItems.append(ellipse)
                count += 1
                
                if mpl :
                    font = {'size':fontsize, 'family':'DejaVu Sans'}
                    plt.rc('font', **font)
                    self.plot_one_galaxy_mpl(multiple_image['x'], multiple_image['y'], a, b, multiple_image['theta'], color=colors_dict[broad_family][:3],
                                             text=multiple_image['id'], linewidth=linewidth, text_color=text_color, text_alpha=text_alpha)
                    #self.plot_one_galaxy_mpl(multiple_image['x'], multiple_image['y'], a, b, multiple_image['theta'], color=colors_dict[broad_family][:3], text=multiple_image['id'])
        
        
        if make_thumbnails :
            if boost is not None :
                adjusted_image = adjust_contrast(self.fits_image.image_data, boost[0], pivot=boost[1])
                adjusted_image = adjust_luminosity(adjusted_image, boost[2])
            else :
                adjusted_image = self.fits_image.image_data
            
            group_images = True
            if group_images :
                group_list = find_close_coord(self.cat[self.mask()], distance)
            else :
                group_list = [[name] for name in self.cat[self.mask()]['id']]
            
            for group in group_list :
                
                x_array = [self.cat[np.where(self.cat['id']==name)[0][0]]['x'] for name in group]
                y_array = [self.cat[np.where(self.cat['id']==name)[0][0]]['y'] for name in group]
                
                x_pix = (np.max(x_array) + np.min(x_array)) / 2
                y_pix = (np.max(y_array) + np.min(y_array)) / 2
                
                half_side = square_size // 2
                
                x_min = round( max( min( np.min(x_array) - margin, x_pix - half_side ), 0) )
                x_max = round( min( max( np.max(x_array) + margin, x_pix + half_side ), self.fits_image.image_data.shape[1]) )
                y_min = round( max( min( np.min(y_array) - margin, y_pix - half_side ), 0) )
                y_max = round( min( max( np.max(y_array) + margin, y_pix + half_side ), self.fits_image.image_data.shape[0]) )
                
                if square_thumbnails :
                    x_side_size = x_max - x_min
                    y_side_size = y_max - y_min
                    if x_side_size!=y_side_size :
                        demi_taille_unique = round( max(x_side_size, y_side_size)/2 )
                        x_pix = round( (x_max + x_min)/2 )
                        y_pix = round( (y_max + y_min)/2 )
                        x_min = x_pix - demi_taille_unique
                        x_max = x_pix + demi_taille_unique
                        y_min = y_pix - demi_taille_unique
                        y_max = y_pix + demi_taille_unique
                
                plt_framework(image=True, figsize=3, drawscaler=1.2)
                font = {'size':9, 'family':'DejaVu Sans'}
                plt.rc('font', **font)
                
                
                #cropped_image = self.fits_image.image_data[y_min:y_max, x_min:x_max, :]
                fig, ax = plot_image_mpl(adjusted_image, wcs=None, wcs_projection=False, units='pixel',
                                         pos=111, make_axes_labels=False, make_grid=False, crop=[x_min, x_max, y_min, y_max])
                
                for multiple_image_id in group :
                    multiple_image = self.cat[np.where(self.cat['id']==multiple_image_id)[0][0]]
                    color = colors_dict[multiple_image_id[:-1]]
                    if not cat_contains_ellipse_params :
                        a, b = 75, 75
                    else :
                        a, b = multiple_image['a'], multiple_image['b']
                    self.plot_one_galaxy_mpl(multiple_image['x']-x_min, multiple_image['y']-y_min, a, b, multiple_image['theta'],
                                             color=color[:3], text=multiple_image['id'], ax=ax, linewidth=linewidth, text_color=text_color, text_alpha=text_alpha)
                
                ax.axis('off')
                #plt.subplots_adjust(left=0, right=1, top=1, bottom=0)
                
                fig.show()
                    
                plot_scale_bar(ax, deg_per_pix=self.fits_image.pix_deg_scale, unit='arcsec',
                               length=1 , color='white', linewidth=2, text_offset=0.01)
                if savefig :
                    fig.savefig(os.path.join(os.path.dirname(self.fits_image.image_path), 'mult_' + group[0]), bbox_inches='tight', pad_inches=0)
                    
                plt_framework(full_tick_framework=True, ticks='out', image=True, width='full', drawscaler=0.8, tickscaler=0.5, minor_ticks=False)
    
    
    def plot_multiple_images_column(self, text_column, which='all', color=None) :
        if text_column not in self.cat.colnames:
            print(f"Column '{text_column}' not found in catalog")
            return
        if not hasattr(self, 'qtItems_column'):
            self.qtItems_column = []
        for text_item in self.qtItems_column:
            self.fits_image.qt_image.removeItem(text_item)
        self.qtItems_column.clear()
        
        if color is not None :
            colors_dict = {}
            if type(color[0])==list :
                for i, family in enumerate(lenstool_model.which) :
                    colors_dict[family] = color[i]
            else :
                for i, family in enumerate(lenstool_model.which) :
                    colors_dict[family] = color
        else :
            colors_dict = lenstool_model.mult_colors(filled_markers=False, saturation=self.saturation)
        
        for name, mask in self.masks().items() :
            broad_family = name#self.cat['broad_family'][ np.where(self.cat['family']==name)[0][0] ]
            for multiple_image in self.cat[mask] :
                
                text = str(multiple_image[text_column])
                text_item = pg.TextItem( text, color=list( np.array(colors_dict[broad_family])*255 )[:3] )
                
                x = multiple_image['x']
                y = self.fits_image.image_data.shape[0] - multiple_image['y']  # Flip y to match PyQtGraph convention
                semi_major = multiple_image['a']
                semi_minor = multiple_image['b']
                offset = max(semi_major, semi_minor)
                text_item.setPos(x + offset/2, y - offset/2)
                
                font = PyQt5.QtGui.QFont()
                font.setPointSize(15)
                text_item.setFont(font)
                
                self.fits_image.qt_image.addItem(text_item)
                self.qtItems_column.append(text_item)
    
    
    getattr(self, AttrName).plot = types.MethodType(plot_multiple_images, getattr(self, AttrName))
    getattr(self, AttrName).plot_column = types.MethodType(plot_multiple_images_column, getattr(self, AttrName))
    
    def transfer_ids(self, id_name='id') :
        if fits_image.imported_cat is not None :
            if id_name in fits_image.imported_cat.cat.colnames :
                temp_cat = match_cat2([self.cat, fits_image.imported_cat.cat], keep_all_col=True, fill_in_value=-1, column_to_transfer=id_name)
                if id_name in self.cat.colnames :
                    id_name = id_name + '_CAT2'
                self.cat[id_name] = temp_cat[id_name]
                print('###############\nColumn ' + id_name + ' added.\n###############')
            else :
                print(id_name + ' not found in imported_cat')
        else :
            print('No imported_cat')
    
    getattr(self, AttrName).transfer_ids = types.MethodType(transfer_ids, getattr(self, AttrName))
    
    
def import_sources(self, predicted_sources_path, fits_image, AttrName='source', units='pixel', filled_markers=False) :
    with open(predicted_sources_path) as file :
        source_lines = file.readlines()[1:]
    sources = Table(names=['id','ra','dec','a','b','theta','z','mag'], dtype=['str', *['float',]*7])
    for line in source_lines :
        sources.add_row(line.split())
    sources['ra'], sources['dec'] = self.relative_to_world(sources['ra'], sources['dec'])
    self.source = fits_image.make_catalog(sources, color=[1.,0.5,0.], units='arcsec')


def export_thumbnails(self, group_images=True, square_thumbnails=True, square_size=150, margin=50, distance=200, export_dir=None, boost=True, make_broad_view=True, broad_view_params=None) :
    export_dir = os.path.join(os.path.dirname(self.fits_image.image_path), 'mult_thumbnails') if export_dir is None else os.path.abspath(os.path.join(export_dir, 'mult_thumbnails'))
    if os.path.isdir( os.path.dirname( os.path.dirname(export_dir) ) ) and not os.path.isdir( os.path.dirname(export_dir) ) :
        os.mkdir(os.path.dirname(export_dir))
    if not os.path.isdir(export_dir) :
        os.mkdir(export_dir)
    
    if not self.fits_image.boosted and boost :
        self.fits_image.boost()
    
    if group_images :
        group_list = find_close_coord(self.cat[self.mask()], distance)
    else :
        group_list = [[name] for name in self.cat[self.mask()]['id']]
    
    for group in group_list :
        
        x_array = [self.cat[np.where(self.cat['id']==name)[0][0]]['x'] for name in group]
        y_array = [self.cat[np.where(self.cat['id']==name)[0][0]]['y'] for name in group]
        
        x_pix = (np.max(x_array) + np.min(x_array)) / 2
        y_pix = (np.max(y_array) + np.min(y_array)) / 2
        
        half_side = square_size // 2
        
        x_min = round( max( min( np.min(x_array) - margin, x_pix - half_side ), 0) )
        x_max = round( min( max( np.max(x_array) + margin, x_pix + half_side ), self.fits_image.image_data.shape[1]) )
        y_min = round( max( min( np.min(y_array) - margin, y_pix - half_side ), 0) )
        y_max = round( min( max( np.max(y_array) + margin, y_pix + half_side ), self.fits_image.image_data.shape[0]) )
        
        #if square_thumbnails :
        x_side_size = x_max - x_min
        y_side_size = y_max - y_min
        demi_taille_unique = round( max(x_side_size, y_side_size)/2 )
        if x_side_size!=y_side_size :
            x_pix = round( (x_max + x_min)/2 )
            y_pix = round( (y_max + y_min)/2 )
            x_min = x_pix - demi_taille_unique
            x_max = x_pix + demi_taille_unique
            y_min = y_pix - demi_taille_unique
            y_max = y_pix + demi_taille_unique
        
        zoom_rect = QRectF(x_min, self.fits_image.image_data.shape[0] - y_max, demi_taille_unique*2, demi_taille_unique*2)
        self.fits_image.qt_image.getView().setRange(zoom_rect)        
        
        
        thumbnail_path = os.path.join( export_dir, 'mult_' + group[0] + '.png' )
        print('Creating ' + thumbnail_path)
        exporter = pg.exporters.ImageExporter(self.fits_image.qt_image.view)
        exporter.export(thumbnail_path)
        print('Done')
        
    
    ##### Adding broad view #####
    if make_broad_view :
        # broad_view_params = [ [x_min, x_max], [y_min, y_max] ]
        if broad_view_params is not None :
            x = broad_view_params[0][0]
            y = self.fits_image.image_data.shape[0] - broad_view_params[1][1]
            x_width = broad_view_params[0][1]-broad_view_params[0][0]
            y_width = broad_view_params[1][1]-broad_view_params[1][0]
            zoom_rect = QRectF(x, y, x_width, y_width)
        else :
            zoom_rect = QRectF(0, 0, self.fits_image.image_data.shape[1], self.fits_image.image_data.shape[0])
        self.fits_image.qt_image.getView().setRange(zoom_rect)        
        
        broadview_filename = 'broadview'
        for name in self.fits_image.lt.which :
            broadview_filename += '_' + name
        broadview_path = os.path.join( export_dir, broadview_filename + '.png' )
        print('Creating ' + broadview_path)
        exporter = pg.exporters.ImageExporter(self.fits_image.qt_image.view)
        exporter.export(broadview_path)
        print('Done')
    ##############################

        



class curves :
    def __init__(self, curves_dir, lenstool_model, fits_image, which_critcaus='critical', join=False, size=2) :
        self.dir = curves_dir
        self.paths = glob.glob(os.path.join(curves_dir, "*.dat"))
        self.lenstool_model = lenstool_model
        self.fits_image = fits_image
        self.size = size
        
        self.qtItems = {}
        for name in lenstool_model.broad_families :
            self.qtItems[name] = None
        
        self.coords = {}
        for name in lenstool_model.broad_families :
            curve_mask = np.array([name in os.path.basename(path) for path in self.paths])
            if True in curve_mask :
                lines = []
                for curve_path in np.array(self.paths)[curve_mask] :
                    file = open(curve_path, 'r')
                    all_lines = file.readlines()
                    lines += all_lines[1:]
                
                ra_ref = float( all_lines[0].split()[-2] )
                dec_ref = float( all_lines[0].split()[-1] )
                
                if which_critcaus=='critical' :
                    delta_ra = np.array( [ float( lines[i].split()[1] ) for i in range(len(lines)) ] )
                    delta_dec = np.array( [ float( lines[i].split()[2] ) for i in range(len(lines)) ] )
                    ra, dec = relative_to_world(delta_ra, delta_dec, (ra_ref, dec_ref))
                    x, y = fits_image.world_to_image(ra, dec)
                    
                    y = fits_image.image_data.shape[0] - y
                    
                    shorten_indices = np.linspace(0, len(x) - 1, 10000, dtype=int)
                    x = x[shorten_indices]
                    y = y[shorten_indices]
                    
                    #if join :
                    #    x, y = rearrange_points(x, y)
                         
                if which_critcaus=='caustic' :
                    delta_ra = np.array( [ float( lines[i].split()[3] ) for i in range(len(lines)) ] )
                    delta_dec = np.array( [ float( lines[i].split()[4] ) for i in range(len(lines)) ] )
                    ra, dec = relative_to_world(delta_ra, delta_dec, (ra_ref, dec_ref))
                    x, y = fits_image.world_to_image(ra, dec)
                    
                    y = fits_image.image_data.shape[0] - y
                    
                    shorten_indices = np.linspace(0, len(x) - 1, 10000, dtype=int)
                    x = x[shorten_indices]
                    y = y[shorten_indices]
                    
                    #if join :
                    #    x, y = rearrange_points(x, y)
                
                self.coords[name] = (x, y)
        
    def plot(self) :
        self.clear()
        for name in self.lenstool_model.which :
            color = np.round(self.lenstool_model.mult_colors(saturation=self.lenstool_model.saturation)[name]*255).astype(int)
            color[3] = 255
            
            x, y = self.coords[name]
            
            scatter = pg.ScatterPlotItem(x, y, pen=None, brush=pg.mkBrush(color), size=self.size)
            self.qtItems[name] = scatter
            self.fits_image.qt_image.addItem(scatter)
            
    def clear(self) :
        for name, qtItem in self.qtItems.items() :
            if qtItem is not None :
                self.fits_image.qt_image.removeItem(qtItem)
                self.qtItems[name] = None
                
    
    








def find_families(image_ids):
    family_ids = image_ids.copy()
    confidence = np.full(len(family_ids), 2)
    for i, name in enumerate(family_ids) :
        if name.startswith('cc') :
            family_ids[i] = name[2:]
            confidence[i] = 0
        elif name.startswith('c') :
            family_ids[i] = name[1:]
            confidence[i] = 1
    
    families = find_families_part2(family_ids)
    
    combined_families = families.copy()
    for i, family in enumerate(families) :
        prefix1 = family.split('.')[0]
        for fam in families :
            prefix2 = fam.split('.')[0]
            if prefix1==prefix2 and family!=fam :
                combined_families[i] = prefix1 + '.'
    #combined_families = np.unique(combined_families)
    
    broad_families = combined_families.copy()
    letter_id = []
    for i, family in enumerate(combined_families) :
        if family[0].isalpha() :
            letter_id.append(i)
            for fam in combined_families :
                if fam[0]==family[0] :
                    broad_families[i] = family[0]
    
    
    
    families_int = families.copy()
    for i in letter_id :
        families_int[i] = str( ord( families[i][0].lower() )-96 )
    
    families_sorted, indices = np.unique(families, return_index=True)
    families_sorted_int = np.array(families_int)[indices]
    
    families_sorted_int = [int(family.split('.')[0]) for family in families_sorted_int]
    families_sorted = families_sorted[np.argsort(families_sorted_int)]
    
    
    
    broad_families_int = broad_families.copy()
    for i in letter_id :
        broad_families_int[i] = str( ord( broad_families[i][0].lower() )-96 )
    
    broad_families_sorted, indices = np.unique(broad_families, return_index=True)
    broad_families_sorted_int = np.array(broad_families_int)[indices]
    
    broad_families_sorted_int = [int(family.split('.')[0]) for family in broad_families_sorted_int]
    broad_families_sorted = broad_families_sorted[np.argsort(broad_families_sorted_int)]
    
    return families, broad_families, families_sorted.tolist(), broad_families_sorted.tolist(), confidence


def find_families_part2(image_ids) :
    # Step 1: Initial guess by chopping last character
    id_to_family = {img_id: img_id[:-1] for img_id in image_ids}
    
    # Step 2: Group by these tentative families
    family_groups = defaultdict(list)
    for img_id, fam in id_to_family.items():
        family_groups[fam].append(img_id)

    # Step 3: Merge singleton families if their name starts with another family name
    updated = True
    while updated:
        updated = False
        singletons = {fam for fam, ids in family_groups.items() if len(ids) == 1}
        for fam in list(singletons):
            for target in family_groups:
                if fam != target and fam.startswith(target):
                    family_groups[target].extend(family_groups[fam])
                    del family_groups[fam]
                    updated = True
                    break
            if updated:
                break

    # Step 4: Merge families with 'alt' in original IDs if the ID starts with another family name
    for fam in list(family_groups):
        for img_id in family_groups[fam]:
            if 'alt' in img_id:
                for target in family_groups:
                    if fam != target and img_id.startswith(target):
                        family_groups[target].extend(family_groups[fam])
                        del family_groups[fam]
                        break
                break  # Only need to check one 'alt' image to trigger a merge

    # Step 5: Build final output mapping
    final_map = {}
    for fam, ids in family_groups.items():
        for img_id in ids:
            final_map[img_id] = fam

    return [final_map[img_id] for img_id in image_ids]




def import_lenstool_files(self) :
    arclets_path_list = glob.glob( os.path.join(self.model_dir, "*arclet*.lenstool") )
    if len(arclets_path_list)==1 :
        arclets_path = arclets_path_list[0]
        print(f"{os.path.basename(arclets_path)} found and used as arclets.")
        import_multiple_images(self, arclets_path, self.fits_image, AttrName='arclets', units='pixel', filled_markers=False)
    else :
        self.arclets = None
                
    predicted_images_path = os.path.join(self.model_dir, 'image.dat')
    if os.path.isfile(predicted_images_path) :
        import_multiple_images(self, predicted_images_path, self.fits_image, AttrName='image', units='pixel', filled_markers=False)
        import_multiple_images(self, predicted_images_path, self.fits_image, AttrName='image_filtered', units='pixel', filled_markers=False)
        self.filter_image()
    else :
        self.image = None
        self.image_filtered = None
    
    curves_dir = os.path.join(self.model_dir, 'curves')
    if os.path.isdir(curves_dir) :
        self.curves = curves(curves_dir, self, self.fits_image, which_critcaus='critical', join=False, size=2)
    else :
        self.curves = None
    
    predicted_sources_path = os.path.join(self.model_dir, 'source.dat')
    if os.path.isfile(predicted_sources_path) :
        import_sources(self, predicted_sources_path, self.fits_image, AttrName='source', units='pixel', filled_markers=False)

